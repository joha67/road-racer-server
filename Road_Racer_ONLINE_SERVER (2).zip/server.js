const express = require('express');
const http = require('http');
const path = require('path');
const { WebSocketServer } = require('ws');

const app = express();
app.get('/', (_req, res) => res.json({ ok: true, service: 'Road Racer online server' }));

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
const rooms = new Map();
let nextId = 1;

function makeId() { return `p${Date.now().toString(36)}${(nextId++).toString(36)}`; }
function makeCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do { code = Array.from({length:6}, () => chars[Math.floor(Math.random()*chars.length)]).join(''); } while (rooms.has(code));
  return code;
}
function send(ws, data) { if (ws.readyState === 1) ws.send(JSON.stringify(data)); }
function view(room) {
  return { code: room.code, hostId: room.hostId, started: room.started, settings: room.settings,
    players: [...room.players.values()].map(p => ({id:p.id,name:p.name,car:p.car,color:p.color})) };
}
function playersPacket(room) {
  return { type:'players', players:[...room.players.values()].map(p => ({
    id:p.id,name:p.name,lane:p.lane,distance:p.distance,speed:p.speed,color:p.color,car:p.car
  }))};
}
function broadcast(room, data, except = null) {
  for (const p of room.players.values()) if (p.ws !== except) send(p.ws, data);
}
function broadcastRoom(room) { broadcast(room, {type:'room', room:view(room)}); broadcast(room, playersPacket(room)); }
function clean(ws) {
  const id = ws.playerId;
  if (!id) return;
  const room = ws.roomCode ? rooms.get(ws.roomCode) : null;
  if (!room) return;
  const wasHost = room.hostId === id;
  room.players.delete(id);
  ws.playerId = null; ws.roomCode = null;
  if (wasHost) {
    broadcast(room, {type:'hostClosed'});
    rooms.delete(room.code);
  } else {
    broadcastRoom(room);
  }
}

wss.on('connection', ws => {
  ws.playerId = makeId();
  ws.roomCode = null;
  send(ws, {type:'welcome', id:ws.playerId});

  ws.on('message', raw => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { send(ws,{type:'error',message:'Неверные данные'}); return; }

    if (data.type === 'createRoom') {
      if (ws.roomCode) clean(ws);
      const code = makeCode();
      const settings = {
        map: data.settings?.map || 'desert',
        laps: Number(data.settings?.laps) || 2,
        obstacles: data.settings?.obstacles || {barrier:true,truck:true,ramp:true,cone:true,boost:true,life:true}
      };
      const name = String(data.name || 'Гонщик').trim().slice(0,16) || 'Гонщик';
      const player = {id:ws.playerId,name,car:'sport',color:'#19c9ff',lane:0,distance:0,speed:0,ws};
      const room = {code,hostId:player.id,started:false,settings,players:new Map([[player.id,player]])};
      rooms.set(code, room); ws.roomCode=code;
      send(ws,{type:'room',room:view(room)}); broadcast(room,playersPacket(room));
      return;
    }

    if (data.type === 'joinRoom') {
      const code = String(data.code || '').trim().toUpperCase();
      const room = rooms.get(code);
      if (!room) { send(ws,{type:'error',message:'Лобби не найдено. Проверь код.'}); return; }
      if (room.started) { send(ws,{type:'error',message:'Гонка уже началась.'}); return; }
      if (room.players.size >= 8) { send(ws,{type:'error',message:'В лобби максимум 8 игроков.'}); return; }
      if (ws.roomCode) clean(ws);
      const name = String(data.name || 'Гонщик').trim().slice(0,16) || 'Гонщик';
      const player = {id:ws.playerId,name,car:'sport',color:'#19c9ff',lane:0,distance:0,speed:0,ws};
      room.players.set(player.id,player); ws.roomCode=code;
      send(ws,{type:'room',room:view(room)}); broadcastRoom(room); return;
    }

    const room = ws.roomCode ? rooms.get(ws.roomCode) : null;
    if (!room) { send(ws,{type:'error',message:'Сначала создай или войди в лобби.'}); return; }
    const player = room.players.get(ws.playerId);
    if (!player) return;

    if (data.type === 'settings') {
      if (room.hostId !== player.id || room.started) return;
      room.settings = {map:data.settings?.map || room.settings.map,laps:Number(data.settings?.laps)||room.settings.laps,obstacles:data.settings?.obstacles || room.settings.obstacles};
      broadcastRoom(room); return;
    }
    if (data.type === 'startRace') {
      if (room.hostId !== player.id || room.started) return;
      room.started = true; broadcast(room,{type:'raceStart',settings:room.settings}); return;
    }
    if (data.type === 'update') {
      player.lane=Number(data.lane)||0; player.distance=Number(data.distance)||0; player.speed=Number(data.speed)||0;
      if (typeof data.color==='string' && /^#[0-9a-fA-F]{6}$/.test(data.color)) player.color=data.color;
      if (['sport','race','bike'].includes(data.car)) player.car=data.car;
      broadcast(room,playersPacket(room),ws); return;
    }
    if (data.type === 'leaveRoom') { clean(ws); return; }
  });
  ws.on('close', () => clean(ws));
  ws.on('error', () => {});
});

const port = Number(process.env.PORT) || 10000;
server.listen(port, '0.0.0.0', () => console.log(`Road Racer online server listening on ${port}`));
